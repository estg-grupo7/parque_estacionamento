/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
//Inclui a biblioteca menu
#include "menu.h"
#include "estruturas.h"
#include "empresa.h"
#include "parque.h"
#include "gestao.h"
#include "tarifarios.h"

void procurar(char stringA[], char tipo);
void procurar_id();

void registar_cliente(){
    /**
     * Esta função é responsável por cadastar os clientes do parque
     */
    system_clear();
    CLIENTES cliente;
    LUGARES lugar;
    
    //variaveis usadas no nif
    int nif[9], i, n, m, total = 0, validado, nif_existe;
    
    //variaveis do tipo de veiculo
    
    char tipo_de_veiculo, tipo_de_veiculo_valido;
    
    //variaveis de matricula
    int j, t, matricula_valida, matricula_existe;
    char matricula[6];
    
    //varivaeis de lugar
    int n_lugares, ocupado, l_desejado;
    
    FILE *fp;
    FILE *cp;
    FILE *cp_write;
    fp = fopen("clientes.txt", "ab");
    
    if(fp == NULL){
        printf("Problemas ao abri o arquivo");
    }else{
        
        cliente.estado = ' ';
        
        cliente.id = contar_clientes() + 1;
        
         asterisco(30, 1);
         printf("Tipos de veiculos\n");

    printf("A  - Autocarro\n");
    printf("B  - Carro\n");
    printf("C  - Camião\n");
    printf("D  - Mota\n");

    asterisco(30, 2);
        
        fflush(stdin);
        printf("Nome: ");
        scanf(" %[^\n]s", cliente.nome);
        
        do{
            total = 0;
            fflush(stdin);
            printf("Nif: ");
            scanf(" %[^\n]s", cliente.nif);
            
            nif_existe = verificar_nif(cliente.nif);
                        
            //armazenar o nif numa variavel de inteiros e colocar os números corretos
            for (i = 0; i < 9; i++)
                nif[i] = (cliente.nif[i] - 48);
            
            //se existir na vairavel nif valores igual a -48 
            //transforma-lo aem zero
            for (n = 0; n < 9; n++)
                if (nif[n] == -48)
                    nif[n] = 0;
            
            if(nif[8] == 0 && nif[7] == 0)
                nif[8] = 10;
            
            //verificar se um nif é válido
            for (m = 0; m < 9; m++) {
                total = total + (nif[m]*(9 - m));
            }
            
            if (total % 11 == 0) {
                printf("Nif Válido\n");
                validado = 1;
            } else {
                printf("Nif Inválido\n");
                validado = 0;
            }
            
            
        }while(validado != 1 || nif_existe != 0);
        
        do{
            fflush(stdin);
            printf("Tipo de Veiculo: ");
            scanf(" %c", &cliente.tipo_veiculo);

            tipo_de_veiculo = cliente.tipo_veiculo;

            switch (tipo_de_veiculo) {
                case 'a':
                case 'A':
                case 'b':
                case 'B':
                case 'c':
                case 'C':
                case 'd':
                case 'D':
                    tipo_de_veiculo_valido = 1;
                    break;
                default:
                    tipo_de_veiculo_valido = 0;

            }
        }while(tipo_de_veiculo_valido != 1);
        
        
        do{
            fflush(stdin);
            printf("Matricula: ");
            scanf(" %[^\n]s", cliente.matricula);
            
            matricula_existe = verificar_matricula(cliente.matricula);

               //transformar a matricula toda em lowercase
            for (j = 0; j < 6; j++){
                cliente.matricula[j] = tolower(cliente.matricula[j]);
            }

            for(t=0;t<6;t++)
                matricula[t] = (cliente.matricula[t] - 48);

            if(matricula[0]+matricula[1]<19 && matricula[2]+matricula[3]<19 && matricula[4]+matricula[5]<19){
                matricula_valida  = 0;
            }else if(matricula[0]+matricula[1]>97 && matricula[2]+matricula[3]<19 && matricula[4]+matricula[5]<19){
                matricula_valida = 1;
            }else if(matricula[0]+matricula[1]<19 && matricula[2]+matricula[3]>97 && matricula[4]+matricula[5]<19){
                matricula_valida = 1;
            }else if(matricula[0]+matricula[1]<19 && matricula[2]+matricula[3]<19 && matricula[4]+matricula[5]>97){
                matricula_valida = 1;
            }else{
                matricula_valida  = 0;
            }
        }while(matricula_valida != 1 || matricula_existe != 0 || strlen(cliente.matricula) > 6 ||strlen(cliente.matricula) < 6 );
        
        cp = fopen("lugares.txt", "rb");
        
        if(cp == NULL){
            printf("Vá em Definições e defina o número de lugares do seu parque!");
        }
        
        cp_write = fopen("lugares.txt", "r+b");
        
        if(cp_write == NULL){
            printf("Vá em Definições e defina o número de lugares do seu parque!");
        }
        
        n_lugares = ver_lugares();
        
        do{
            fflush(stdin);
            printf("Qual o lugar que pretende? ");
            scanf("%d", &l_desejado);

            if(l_desejado > n_lugares){
                printf("Este lugar não existe!");
            }else{
                fseek(cp,(l_desejado-1)*sizeof(LUGARES), SEEK_SET);
                fread(&lugar, sizeof(LUGARES), 1, cp);

                if(lugar.ativo == 0){
                    rewind(cp_write);
                    fseek(cp_write,(l_desejado-1)*sizeof(LUGARES), SEEK_SET);
                    fread(&lugar, sizeof(LUGARES), 1, cp_write);
                    lugar.id_cliente = cliente.id;
                    lugar.ativo = 1;
                    strlcpy(lugar.matricula, cliente.matricula, 7);
                    fseek(cp_write, -(long) sizeof(LUGARES), SEEK_CUR);
                    fwrite(&lugar, sizeof(LUGARES),1,cp_write);
                    cliente.lugar = l_desejado;
                    ocupado = 0;
                }else{
                    printf("Este Lugar está ocupado!");
                    ocupado = 1;
                }
            }
        }while(ocupado != 0 || l_desejado < 0);
        
        
        
        fwrite(&cliente, sizeof(CLIENTES), 1, fp);
    }
    fclose(cp_write);
    fclose(cp);
    fclose(fp);
}

void listar_clientes(){
    /**
     * Esta função és responsável por listar os clientes ativos do parque
     */
    system_clear();
    struct CLIENTES cliente;
    int count = 0;
    FILE *fp;
    
    fp = fopen("clientes.txt", "rb");
    
    int t;
    
    if(fp == NULL){
        printf("Problemas ao tentar abrir o ficheiro!\n");
    }else{
        printf("Id");dar_espacos(4, 8);
        printf("Nif");dar_espacos(10, 20); 
        printf("Nome");dar_espacos(50, 100);          
        printf("Matricula");dar_espacos(7, 14); 
        printf("Tipo de Veiculo");dar_espacos(10, 20); 
        printf("Lugar\n");
        while(fread(&cliente, sizeof(CLIENTES), 1, fp) == 1){
            count++;
            if(cliente.estado!='*'){
                printf("%d", cliente.id);dar_espacos(5, 10); 
                printf("%s", cliente.nif);dar_espacos(4, 8); 
                printf("%s", cliente.nome);dar_espacos_nome(54, cliente.nome);  
                printf("%s", cliente.matricula);dar_espacos(10, 20);  
                printf("%c", cliente.tipo_veiculo);dar_espacos(24, 48);  
                printf("%d\n", cliente.lugar);
            }
        }
    }
        fclose(fp);
}

int verificar_nif(char nif[]){
    /**
     * Esta função é reponsável por verificar se um 
     * determindado NIF já se encontra registado na base de dados
     * 
     * @param nif recebe o nif que pretende verificar se existe
     * @return retorna o número de nif iguais, se for == 0 não existe nenhum nif igual, se for > significa que o nif já se encontra na base de dados
     */
    struct CLIENTES cliente;
    int contar = 0;
    
    FILE *fp;
    
    fp = fopen("clientes.txt", "rb");
    
    if(fp == NULL){
        printf("Erro ao tentar abrir o ficheiro!\n");
    }else{
        while(fread(&cliente, sizeof(CLIENTES), 1, fp)==1){
            if(cliente.estado != '*')
                if(strcmp(nif,cliente.nif)==0)
                    contar++;
        }
    }
    fclose(fp);
    
    return contar;
}

int verificar_matricula(char matricula[]){
    /*
     * Esta função é reponsável por verificar se uma 
     * determindada Matricula já se encontra registada na base de dados
     */
    /**
     * * Esta função é reponsável por verificar se uma 
     * determindada Matricula já se encontra registada na base de dados
     * 
     * @param matricula recebe a matrcicula que se prentende verificar se existe na base de dados
     * @return retorna o número de matriculas iguais, se for == 0 não existe nenhum matricula igual, se for > significa que a matricula já se encontra na base de dados
     */
    struct CLIENTES cliente;
    
    int contar = 0;
    
    FILE *fp;
    
    fp  = fopen("clientes.txt", "rb");
    
    if(fp == NULL){
        printf("Erro ao tentar abrir o ficheiro!\n");
    }else{
        while(fread(&cliente, sizeof(CLIENTES), 1, fp) == 1){
            if(cliente.estado != '*')
                if(strcmp(matricula, cliente.matricula)==0)
                    contar++;
        }
    }
    fclose(fp);
    
    return contar;
}

void alterar_cliente(){
    system_clear();
    /*
     * Esta função é responsável por alterar os dados de um cliente
     */
    
    /**
     * Esta função és responsável por alterar os dados de um cliente que se encontre registado
     */
    
    struct CLIENTES cliente;
    int opcao;
    int numero_registo;
    
        //variaveis usadas no nif
    int nif[9], i, n, m, total = 0, validado, nif_existe;
    
    //variaveis do tipo de veiculo
    
    char tipo_de_veiculo, tipo_de_veiculo_valido;
    
    //variaveis de matricula
    int j, t, matricula_valida, matricula_existe;
    char matricula[6];
    
    FILE *fp;
    
    fp = fopen("clientes.txt", "r+b");
    
    printf("Introduza o registo a alterar: ");
    scanf("%d", &numero_registo);
    
    if(fp == NULL){
        printf("Erro ao tentar abrir o ficheiro!\n");
    }else{
        
        fseek(fp,(numero_registo-1)*sizeof(CLIENTES), SEEK_SET);
        
        fread(&cliente, sizeof(CLIENTES), 1, fp);
        do{
            do{
                puts("1 - Alterar Nome");
                puts("2 - Alterar Nif");
                puts("3 - Alterar Tipo de Veiculo");
                puts("4 - Alterar Matricula");
                puts("0 - Voltar");
                printf("Selecione uma opção: ");
                scanf("%d", &opcao);
                system_clear();
            }while(opcao<0 || opcao > 4);
            
            switch(opcao){
            case 1:                  
                fflush(stdin);
                printf("Nome: ");
                scanf(" %[^\n]s", cliente.nome);
                break;
            case 2:
                do{
            total = 0;
            fflush(stdin);
            printf("Nif: ");
            scanf(" %[^\n]s", cliente.nif);
            
            nif_existe = verificar_nif(cliente.nif);
                        
            //armazenar o nif numa variavel de inteiros e colocar os números corretos
            for (i = 0; i < 9; i++)
                nif[i] = (cliente.nif[i] - 48);
            
            //se existir na vairavel nif valores igual a -48 
            //transforma-lo aem zero
            for (n = 0; n < 9; n++)
                if (nif[n] == -48)
                    nif[n] = 0;
            
            //verificar se um nif é válido
            for (m = 0; m < 9; m++) {
                total = total + (nif[m]*(9 - m));
            }
            
            if (total % 11 == 0) {
                printf("Nif Válido\n");
                validado = 1;
            } else {
                printf("Nif Inválido\n");
                validado = 0;
            }
            
            
        }while(validado != 1 || nif_existe != 0);
                break;
            case 3:
                
        
        do{
            fflush(stdin);
            printf("Tipo de Veiculo: ");
            scanf(" %c", &cliente.tipo_veiculo);

            tipo_de_veiculo = cliente.tipo_veiculo;

            switch (tipo_de_veiculo) {
                case 'a':
                case 'A':
                case 'b':
                case 'B':
                case 'c':
                case 'C':
                case 'd':
                case 'D':
                    tipo_de_veiculo_valido = 1;
                    break;
                default:
                    tipo_de_veiculo_valido = 0;

            }
        }while(tipo_de_veiculo_valido != 1);
                break;
            case 4:
                
        do{
            fflush(stdin);
            printf("Matricula: ");
            scanf(" %[^\n]s", cliente.matricula);
            
            matricula_existe = verificar_matricula(cliente.matricula);

               //transformar a matricula toda em lowercase
            for (j = 0; j < 6; j++){
                cliente.matricula[j] = tolower(cliente.matricula[j]);
            }

            for(t=0;t<6;t++)
                matricula[t] = (cliente.matricula[t] - 48);

            if(matricula[0]+matricula[1]<19 && matricula[2]+matricula[3]<19 && matricula[4]+matricula[5]<19){
                matricula_valida  = 0;
            }else if(matricula[0]+matricula[1]>97 && matricula[2]+matricula[3]<19 && matricula[4]+matricula[5]<19){
                matricula_valida = 1;
            }else if(matricula[0]+matricula[1]<19 && matricula[2]+matricula[3]>97 && matricula[4]+matricula[5]<19){
                matricula_valida = 1;
            }else if(matricula[0]+matricula[1]<19 && matricula[2]+matricula[3]<19 && matricula[4]+matricula[5]>97){
                matricula_valida = 1;
            }else{
                matricula_valida  = 0;
            }
        }while(matricula_valida != 1 || matricula_existe != 0 || strlen(cliente.matricula) > 6 ||strlen(cliente.matricula) < 6 );
                break;
        }

     
            
        }while(opcao!=0);
        
        
        
        
        

           fseek(fp,-(long) sizeof(CLIENTES), SEEK_CUR);

           fwrite(&cliente, sizeof(CLIENTES), 1, fp);
    }
    
    fclose(fp);

}

int contar_clientes(){
    
    /**
     * Esta função é usada para gerar o id do cliente
     * 
     * @return o número total de clientes ativos e apagados
     */
    
    FILE *fp;
    
    int total_clientes = 0;
    
    CLIENTES cliente;
    
    fp = fopen("clientes.txt", "rb");
    
    if(fp==NULL){
        printf("Erro ao tentar abrir o ficheiro!\n");
    }else{
        while(fread(&cliente, sizeof(CLIENTES), 1, fp) == 1){
            total_clientes++;
        }
    }
    
    fclose(fp);
    
    return total_clientes;
    
}

void remover_cliente(){
    /**
     * Esta função é responsável por "apagar" o cliente da base de dados, 
     * pois este não é completamente apagado, o seu estado é atualizado para '*'
     */
    system_clear();
    CLIENTES cliente;
    LUGARES lugar;
    
    FILE *removeC;
    FILE *removeP;
    
    int id_cliente;
    
    int n_clientes;
    
    char matricula[7] = "aaaaaa";
    
    int contar = 0;
    
    removeC = fopen("clientes.txt", "r+b");
    
    if(removeC == NULL){
        printf("Erro ao tentar abrir o ficheiro!\n");
    }
    
    removeP = fopen("lugares.txt", "r+b");
    
    if(removeP == NULL){
        printf("Erro ao tentar abrir o ficheiro!\n");
    }
    
    printf("Qual é o Cliente que deseja remover? ");
    scanf("%d", &id_cliente);
    
    n_clientes = contar_clientes();
    
    if(id_cliente > n_clientes){
        printf("O cliente com o id %d não existe!\n", id_cliente);
    }else{
        fseek(removeC, (id_cliente) * sizeof(CLIENTES), SEEK_SET);
        cliente.estado = '*';     
        fseek(removeC, -(long) sizeof(CLIENTES), SEEK_CUR);
        fwrite(&cliente, sizeof(CLIENTES), 1, removeC);
        
       
        
        while(fread(&lugar, sizeof(LUGARES),1,removeP) == 1){
            if(lugar.id_cliente == id_cliente){
                fseek(removeP, (contar - 1) * sizeof(LUGARES), SEEK_SET);
                lugar.ativo = 0;
                lugar.id_cliente = 0;
                strlcpy(lugar.matricula, matricula, 7);
        
                fseek(removeP, -(long) sizeof(LUGARES), SEEK_CUR);
                fwrite(&lugar, sizeof(LUGARES), 1, removeP);
            }
            contar++;
        }
    }
    fclose(removeP);
    fclose(removeC);
}

void procurar_cliente(){
    /**
     * Esta função é reponsável por gerar um menu onde o administrador
     * consegues procurar um determinado cliente ativo na base de dados
     */
    system_clear();
    CLIENTES cliente;
    //nif
    int total, i, validado, n, m;
    char nif[9+1];

    
    //matricula
    char matricula[6+1];
    int j, t, matricula_valida;
    
    int opcao;
    char nome[50];
    do{
        do{
            puts("Procurar por:");
            puts("1 - Nome");
            puts("2 - NIF");
            puts("3 - Matricula");
            puts("4 - Id Utilizador");
            puts("0 - Voltar");
            printf("Selecione uma opção: ");
            scanf("%d", &opcao);
            system_clear();
        }while(opcao < 0 || opcao > 4);
        
        switch(opcao){
            case 1:
                printf("Nome a procurar: ");
                scanf(" %[^\n]s", nome);
                procurar(nome, 'n');
                break;
            case 2:
                do{
                    total = 0;
                    fflush(stdin);
                    printf("Nif: ");
                    scanf(" %[^\n]s", cliente.nif);

                    //armazenar o nif numa variavel de inteiros e colocar os números corretos
                    for (i = 0; i < 9; i++)
                        nif[i] = (cliente.nif[i] - 48);

                    //se existir na vairavel nif valores igual a -48 
                    //transforma-lo aem zero
                    for (n = 0; n < 9; n++)
                        if (nif[n] == -48)
                            nif[n] = 0;

                    //verificar se um nif é válido
                    for (m = 0; m < 9; m++) {
                        total = total + (nif[m]*(9 - m));
                    }

                    if (total % 11 == 0) {
                        printf("Nif Válido\n");
                        validado = 1;
                    } else {
                        printf("Nif Inválido\n");
                        validado = 0;
                    }

                }while(validado != 1);
                procurar(cliente.nif, 'm');
                break;
            case 3:
                do{
                    fflush(stdin);
                    printf("Matricula: ");
                    scanf(" %[^\n]s", cliente.matricula);

                       //transformar a matricula toda em lowercase
                    for (j = 0; j < 6; j++){
                        cliente.matricula[j] = tolower(cliente.matricula[j]);
                    }

                    for(t=0;t<6;t++)
                        matricula[t] = (cliente.matricula[t] - 48);

                    if(matricula[0]+matricula[1]<19 && matricula[2]+matricula[3]<19 && matricula[4]+matricula[5]<19){
                        matricula_valida  = 0;
                    }else if(matricula[0]+matricula[1]>97 && matricula[2]+matricula[3]<19 && matricula[4]+matricula[5]<19){
                        matricula_valida = 1;
                    }else if(matricula[0]+matricula[1]<19 && matricula[2]+matricula[3]>97 && matricula[4]+matricula[5]<19){
                        matricula_valida = 1;
                    }else if(matricula[0]+matricula[1]<19 && matricula[2]+matricula[3]<19 && matricula[4]+matricula[5]>97){
                        matricula_valida = 1;
                    }else{
                        matricula_valida  = 0;
                    }
                }while(matricula_valida != 1 || strlen(cliente.matricula) > 6 ||strlen(cliente.matricula) < 6 );
                procurar(cliente.matricula, 'd');
                break;
            case 4:
                procurar_id();
                break;
        }
    }while(opcao!=0);
}


void procurar(char stringA[], char tipo){
    
    /**
     * Esta função é responsável por procurar um cliente na base de dados através do nome, nif, matricula
     * @param stringA recebe o nif ou o nome ou a matricula que se deseja procurar na base de dados
     * @param tipo para verficar se se trata de uma matricula 'd', de um nome 'n' , ou de um nif 'm'
     */
    
    CLIENTES cliente;
    
    FILE *procurar;
        
    procurar = fopen("clientes.txt", "rb");
    
    if(procurar == NULL){
        printf("Erro ao tentar abrir o ficheiro!\n");
    }
            
    while(fread(&cliente, sizeof(CLIENTES),1,procurar) == 1){
        if(tipo == 'n'){
            if(strcmp(stringA,cliente.nome) == 0){
                   printf("%d\t", cliente.id);
                   printf("%s\t", cliente.nif);
                   printf("%s\t", cliente.nome);
                   printf("%s\t", cliente.matricula);
                   printf("%c\t", cliente.tipo_veiculo);
                   printf("%d\t", cliente.lugar);
                   printf(" %c\t\n", cliente.estado);
        }
        }else if(tipo == 'm'){
            if(strcmp(stringA,cliente.nif) == 0){
                   printf("%d\t", cliente.id);
                   printf("%s\t", cliente.nif);
                   printf("%s\t", cliente.nome);
                   printf("%s\t", cliente.matricula);
                   printf("%c\t", cliente.tipo_veiculo);
                   printf("%d\t", cliente.lugar);
                   printf(" %c\t\n", cliente.estado);
            }
        }else if(tipo == 'd'){
            if(strcmp(stringA,cliente.matricula) == 0){
                   printf("%d\t", cliente.id);
                   printf("%s\t", cliente.nif);
                   printf("%s\t", cliente.nome);
                   printf("%s\t", cliente.matricula);
                   printf("%c\t", cliente.tipo_veiculo);
                   printf("%d\t", cliente.lugar);
                   printf(" %c\t\n", cliente.estado);
            }
        }else{
            printf("Nenhum Utilizador Encontrado!\n");
        }
        

    }
  
        
     
    
    
    
    fclose(procurar);
}


void procurar_id(){
    /**
     * Esta dunção permite obter um cliente pelo seu id único
     */
    system_clear();
    CLIENTES cliente;
    
    int id;
        
    FILE *procurarId;
        
    procurarId = fopen("clientes.txt", "rb");
    
    if(procurarId == NULL){
        printf("Erro ao tentar abrir o ficheiro!\n");
    }
    
    printf("Id Cliente: ");
    scanf("%d", &id);
            
    while(fread(&cliente, sizeof(CLIENTES),1,procurarId) == 1){
        if(id == cliente.id){
                   printf("%d\t", cliente.id);
                   printf("%s\t", cliente.nif);
                   printf("%s\t", cliente.nome);
                   printf("%s\t", cliente.matricula);
                   printf("%c\t", cliente.tipo_veiculo);
                   printf(" %c\t\n", cliente.estado);
        }
    }
  
        
     
    
    
    
    fclose(procurarId);
}