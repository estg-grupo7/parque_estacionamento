/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//Este ficheiro é responsável por ir buscar os tarifarios

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
//Inclui a biblioteca menu
#include "menu.h"
#include "estruturas.h"
#include "empresa.h"
#include "gestao.h"
#include "tarifarios.h"

void tarifarios(){
    /**
     * Esta função é responsável por gerar o menu de gestao de tarifarios
     */
    TARIFARIO tarifa;
    
    int opcao, id_tarifario, rid_tarifario;
    
    do{
        do{
            puts("1 - Adcionar tarifa com intervalos");
            puts("2 - Definir tarifa por minutos");
            puts("3 - Alterar tarifa por intervalos");
            puts("4 - Ver Tarifarios");
            puts("5 - Apagar Tarifario");
            printf("Escolha uma opção: ");
            scanf("%d", &opcao);
            system_clear();
        }while(opcao < 0 || opcao > 5);
        switch(opcao){
            case 1:
                adicionar_tarifa_intervalos();
                break;
            case 2:
                definir_tarifa_minutos();
                break;
            case 3:
                printf("Qual a tarifa que deseja alterar? ");
                scanf("%d", &id_tarifario);
                alterar_tarifario(id_tarifario);
                break;
            case 4:
                listar_tarifarios();
                break;
            case 5:
                printf("Qual a tarifa que deseja remover? ");
                scanf("%d", &rid_tarifario);
                remover_tarifario(rid_tarifario);
                break;
        }
    }while(opcao!=0);
    
}

void adicionar_tarifa_intervalos(){
    
    /**
     * Esta Função é responsável por adicionar uma tarifa
     */
    
    TARIFARIO tarifa;
    
    int tarifario_existe;
    
    FILE *fp;
    
    FILE *fr;

    fp = fopen("tarifario.txt", "ab");

    if(fp == NULL){
        printf("Erro ao tentar abrir o ficheiro!");
    }
    
    fr = fopen("tarifario.txt", "rb");

    if(fr == NULL){
        printf("Erro ao tentar abrir o ficheiro!");
    }
    printf("Introduza os intervalos de tempo em minutos!\n");
        tarifa.id = contar_tarifas() + 1;
        tarifa.tempo_minutos = 0;
        tarifa.ativo = 1;
        tarifa.mensalidade = 0;
        tarifa.tempo_minutos = 0;
        
        fflush(stdin);
        printf("Intervalo Minimo: ");
        scanf("%f", &tarifa.tempo_min);

        fflush(stdin);
        printf("Intervalo Máximo: ");
        scanf("%f", &tarifa.tempo_max);

        fflush(stdin);
        printf("Preço: ");
        scanf("%f", &tarifa.preco);
        
        tarifario_existe = verificar_limites_tempo(tarifa.tempo_min, tarifa.tempo_max);
        if(tarifario_existe == 0 && tarifa.tempo_min < tarifa.tempo_max)
            fwrite(&tarifa, sizeof(TARIFARIO), 1, fp);
        else{
            if(tarifa.tempo_min >= tarifa.tempo_max)
                printf("O Tempo Minimo não pode ser menor ou igual ao Tempo Máximo!\n");
            printf("Este inverlado já existe!\n");
            printf("Atualize primeiro os tarifarios existentes!\n");
        }
        
                
    fclose(fr);
    fclose(fp);
}

void listar_tarifarios(){
    /**
     * Esta função é reponsável por listar todos os tarifarios
     */
    TARIFARIO tarifa;
    FILE *fr;

    fr = fopen("tarifario.txt", "rb");

    if(fr == NULL){
        printf("Erro ao tentar abrir o ficheiro!");
    }
  
    rewind(fr);
    
    while(fread(&tarifa, sizeof(TARIFARIO),1,fr)==1){
        if(tarifa.ativo == 1){
            printf("Id: %d", tarifa.id);
            printf("Tempo Min: %f", tarifa.tempo_min);
            printf("Tempo MAx: %f", tarifa.tempo_max);
            printf("Preço: %f\n", tarifa.preco);
        }
    }
    
    fclose(fr);
}

int verificar_limites_tempo(float a, float b){
    
    /**
     * 
     * Esta função é responsável por verificar se um determinado intervalo de tarifario existe
     * 
     * @param a recebe o tempo minimo do tarifario
     * @param b recebe o tempo maximo do tarifario
     * @return se existir o tarifario retorna 1 senão retorna 0
     */
    
    int existe = 0;
    
    TARIFARIO tarifa;
    
    int pode;
    
    FILE *read;
    
    read = fopen("tarifario.txt", "rb");
    
    if(read == NULL){
        printf("Erro ao tentar abrir o ficheiro!\n");
    }
    
    while(fread(&tarifa, sizeof(TARIFARIO),1,read ) == 1 && tarifa.ativo == 1){
        if(a == tarifa.tempo_min)
            existe++;
        if(b == tarifa.tempo_max)
            existe++;
        
        if(a > tarifa.tempo_min && a < tarifa.tempo_min && b > tarifa.tempo_min && b < tarifa.tempo_min){
            pode = 1;
        }else if(a < tarifa.tempo_min && b < tarifa.tempo_min){
            pode = 1;
        }else if(a > tarifa.tempo_max && b > tarifa.tempo_max){
            pode = 1;
        }else{
            pode = 0;
        }
    }
    
    if(existe > 0 || pode == 0)
        return 1;
    else 
        return 0;
    
    fclose(read);
}

int contar_tarifas(){
    
    /**
     * Esta função é resonsável por contar quantos tarifarios existem
     * 
     * @return o número de tarifarios existentes
     */
    
    TARIFARIO tarifa;
    
    int contar = 0;
    
    FILE *read;
    
    read = fopen("tarifario.txt", "rb");
    
    if(read == NULL){
        printf("Erro ao tentar abrir o ficheiro!\n");
    }
    
    while(fread(&tarifa, sizeof(TARIFARIO),1,read ) == 1){
        contar++;
    }
  
    return contar;
    
    fclose(read);
}

void alterar_tarifario(int id_tarifario){
    
    /**
     * Esta função é responsavel por alterar um tarifario atraves do seu id
     * @param id_tarifario recebe o id do tarifario que deseja alterar
     */
    
    
    TARIFARIO tarifa;
    
    int tarifario_existe;
    
    FILE *fileWrite;
    
    int n_tarifarios;
 
    
    fileWrite = fopen("tarifario.txt", "r+b");
    
    if(fileWrite == NULL){
        printf("Erro ao tentar abrir o ficehiro!\n");
    }
    
    n_tarifarios = contar_tarifas();
    
    if(id_tarifario > n_tarifarios)
        printf("Este tarifário não existe!\n");
    else{
        fseek(fileWrite, (id_tarifario) * sizeof(TARIFARIO), SEEK_SET);
        
        
        tarifa.id = id_tarifario;
        tarifa.tempo_minutos = 0;
        tarifa.ativo = 1;
        tarifa.mensalidade = 0;
        tarifa.tempo_minutos = 0;
        
        fflush(stdin);
        printf("Intervalo Minimo: ");
        scanf("%f", &tarifa.tempo_min);

        fflush(stdin);
        printf("Intervalo Máximo: ");
        scanf("%f", &tarifa.tempo_max);

        fflush(stdin);
        printf("Preço: ");
        scanf("%f", &tarifa.preco);
        
        tarifario_existe = verificar_limites_tempo(tarifa.tempo_min, tarifa.tempo_max);
        
        if(tarifario_existe == 0 && tarifa.tempo_min < tarifa.tempo_max){
            fseek(fileWrite, -(long) sizeof(TARIFARIO), SEEK_CUR);
            fwrite(&tarifa, sizeof(TARIFARIO), 1, fileWrite);
        }else{
            if(tarifa.tempo_min >= tarifa.tempo_max)
                printf("O Tempo Minimo não pode ser menor ou igual ao Tempo Máximo!\n");
            printf("Este inverlado já existe!\n");
            printf("Atualize primeiro os tarifarios existentes!\n");
        }
        
        
    }
    
    fclose(fileWrite);
    
}

void remover_tarifario(int id_tarifario){
    
    /**
     * Esta função é responsavel por remover um tarifario atraves do seu id
     * @param id_tarifario recebe o id do tarifario que deseja remover
     */
    
    
    TARIFARIO tarifa;
    
    int tarifario_existe;
    
    FILE *fileWrite;
    
    int n_tarifarios;
 
    
    fileWrite = fopen("tarifario.txt", "r+b");
    
    if(fileWrite == NULL){
        printf("Erro ao tentar abrir o ficehiro!\n");
    }
    
    n_tarifarios = contar_tarifas();
    
    if(id_tarifario > n_tarifarios)
        printf("Este tarifário não existe!\n");
    else{
        fseek(fileWrite, (id_tarifario) * sizeof(TARIFARIO), SEEK_SET);
        

        tarifa.ativo = 0;
        
        fseek(fileWrite, -(long) sizeof(TARIFARIO), SEEK_CUR);
        fwrite(&tarifa, sizeof(TARIFARIO), 1, fileWrite);
        
    }
    
    fclose(fileWrite);
    
}

void definir_tarifa_minutos(){
    
    /**
     * Esta função é responsável por definir o preço do parque por minuto
     */
    
    TARIFARIO tarifa;
    
    FILE *tpm;
    
    tpm = fopen("mtarifario.txt", "wb");
    
    if(tpm == NULL){
        printf("Erro ao tentar abrir ficheiro!");
    }
    
    printf("Introduza o preço por minutos desejado: ");
    scanf("%f", &tarifa.preco);
            
    tarifa.id = 0;
    tarifa.tempo_minutos = 0;
    tarifa.ativo = 1;
    tarifa.mensalidade = 0;
    tarifa.tempo_minutos = 0;
    tarifa.tempo_max = 0;
    tarifa.tempo_min = 0;
    
    fclose(tpm);
    
}
