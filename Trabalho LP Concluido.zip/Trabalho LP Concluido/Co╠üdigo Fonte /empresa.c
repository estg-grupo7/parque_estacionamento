/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
//Inclui a biblioteca menu
#include "menu.h"
#include "estruturas.h"
#include "empresa.h"
#include "gestao.h"
#include "tarifarios.h"


void empresa(){
    
    /**
     * Esta função é responsável por gerar dados realtivos à empresa prestadora do serviço de estacionamento
     * Esta pode definir o seu:
     * ->nome
     * ->nif
     * ->número de lugares do parque
     * 
     * Pode também ver, adicionar, remover tarifarios;
     * Pode ainda definir o sistema pelo qual deseja aplicar as tarifas:
     * ->por intervalo de tempo;
     * ->preço por minuto que esteja no parque
     * 
     * O sistema ainda diz o troco que o cliente deve receber mediante a quantia entregue
     */
    
    EMPRESA empresa;
    int opcao;
    
    int i, total = 0, nif[9], m, validado, n, nipc;
    
    FILE *fp;
    
    fp = fopen("empresa.txt", "r+b");
    
    //Verifica se o ficheiro existe
    if(fp==NULL){
        
        
        printf("Erro ao tentar abrir ficheiro!\n");
        //Como não existe cria um novo ficheiro;
        fp = fopen("empresa.txt", "ab");
        
        
        //Solicita informações sobre a empresa
        printf("Introduza o novo Nome da Empresa: ");
        scanf(" %[^\n]s", empresa.nome);
        
        do{
                            nipc = 0;
                            total = 0;
                            fflush(stdin);
                            printf("Nif: ");
                            scanf(" %[^\n]s", empresa.nif);

                            //armazenar o nif numa variavel de inteiros e colocar os números corretos
                            for (i = 0; i < 9; i++)
                                nif[i] = (empresa.nif[i] - 48);

                            //se existir na vairavel nif valores igual a -48 
                            //transforma-lo aem zero
                            for (n = 0; n < 9; n++)
                                if (nif[n] == -48)
                                    nif[n] = 0;

                            if(nif[8] == 0)
                                nif[8] = 10;

                            if(nif[0] == 5 ){
                                nipc = 1;
                            }else if(nif[0] == 6 ){
                                nipc = 1;
                            }else if(nif[0] == 8){
                                nipc = 1;
                            }else if(nif[0] == 9){

                            }else{
                                printf("Este Nif é inválido pois não é um Número de identificação coletiva");
                                nipc = 0;
                            }

                            //verificar se um nif é válido
                            for (m = 0; m < 9; m++) {
                                total = total + (nif[m]*(9 - m));
                            }

                            if (total % 11 == 0) {
                                printf("Nif Válido\n");
                                validado = 1;
                            } else {
                                printf("Nif Inválido\n");
                                validado = 0;
                            }


                        }while(validado != 1 || nipc != 1);
                        
                        fflush(stdin);
                        printf("Número de Lugares:");
                        scanf("%d", &empresa.lugares);
                        
                        do{
                           puts("Escolha o tipo de tarifa: ");
                           puts("1 - Tarifa por intervalos");
                           puts("2 - Tarifa por minutos");
                           fflush(stdin);
                           printf("Selecione uma opção do menu: ");
                           scanf("%d", &empresa.tarifario);
                    }while(empresa.tarifario != 1 && empresa.tarifario != 2);   
    }
    
    while(fread(&empresa, sizeof(EMPRESA), 1, fp) == 1){
        printf("Nome Empresa: %s\n", empresa.nome);
        printf("Nif: %s\n", empresa.nif);
        printf("Número de lugares: %d\n", empresa.lugares);
        if(empresa.tarifario == 1)
            puts("Tarifário por intervalos.");
        else if(empresa.tarifario == 2)
            puts("Tarifário por intervalos.");
        
    }
    
    do{
        do{
            printf("\n");
            puts("1 - Definir Nome Empresa");
            puts("2 - Definir Nif Empresa");
            puts("3 - Definir o número de lugares");
            puts("4 - Tarifario");
            puts("5 - Alterar Tipo Tarifário");
            puts("0 - Voltar");
            scanf("%d", &opcao);
            system_clear();
        }while(opcao<0 || opcao >5);
            fseek(fp, 0*sizeof(EMPRESA), SEEK_SET);

            switch(opcao){
                case 1:
                        printf("Introduza o novo Nome da Empresa: ");
                        scanf(" %[^\n]s", empresa.nome);
                    break;
                case 2:
                    do{
                            nipc = 0;
                            total = 0;
                            fflush(stdin);
                            printf("Nif: ");
                            scanf(" %[^\n]s", empresa.nif);

                            //armazenar o nif numa variavel de inteiros e colocar os números corretos
                            for (i = 0; i < 9; i++)
                                nif[i] = (empresa.nif[i] - 48);

                            //se existir na vairavel nif valores igual a -48 
                            //transforma-lo aem zero
                            for (n = 0; n < 9; n++)
                                if (nif[n] == -48)
                                    nif[n] = 0;

                            if(nif[8] == 0)
                                nif[8] = 10;

                            if(nif[0] == 5 ){
                                nipc = 1;
                            }else if(nif[0] == 6 ){
                                nipc = 1;
                            }else if(nif[0] == 8){
                                nipc = 1;
                            }else if(nif[0] == 9){

                            }else{
                                printf("Este Nif é inválido pois não é um Número de identificação coletiva");
                                nipc = 0;
                            }

                            //verificar se um nif é válido
                            for (m = 0; m < 9; m++) {
                                total = total + (nif[m]*(9 - m));
                            }

                            if (total % 11 == 0) {
                                printf("Nif Válido\n");
                                validado = 1;
                            } else {
                                printf("Nif Inválido\n");
                                validado = 0;
                            }


                        }while(validado != 1 || nipc != 1);
                    break;
                case 3:
                        fflush(stdin);
                        printf("Número de Lugares:");
                        scanf("%d", &empresa.lugares);
                        flugares(empresa.lugares);
                    break;
                case 4:
                    tarifarios();
                    break;
                case 5:
                    do{
                           puts("Escolha o tipo de tarifa: ");
                           puts("1 - Tarifa por intervalos");
                           puts("2 - Tarifa por minutos");
                           scanf("%d", &empresa.tarifario);
                           system_clear();
                    }while(empresa.tarifario != 1 && empresa.tarifario != 2);                    
                    break;
            }
            fseek(fp, -(long)sizeof(EMPRESA), SEEK_CUR);
            fwrite(&empresa, sizeof(EMPRESA), 1, fp);
    }while(opcao!=0);

    fclose(fp);
}

void estatisticas(){
    
    /**
     * Esta função responsável por gerar as estatisticas relativas a empresa.
     * Dados como:
     * -total utilizadores;
     * -total utilizadores de hoje;
     * -total utilizadores  deste mes;
     * -total utilizadores deste ano;
     * 
     * -tempo medio utilizadores de hoje;
     * -tempo medio utilizadores  deste mes;
     * -tempo medio utilizadores deste ano;
     */
    
    PARQUEAMENTO parque;
    
    FILE *estatisticas;
    
    int hoje, mes, ano;
    
    int total, media;
    
    int contar_utilizadores = 0;
    
    //nº utilizadores
    int contar_dia = 0;
    int contar_mes = 0;
    int contar_ano = 0;
    
    //tempo utilizadores
    
    float tempo_dia = 0;
    float tempo_mes = 0;
    float tempo_ano = 0;
    
    float media_tempo_dia;
    float media_tempo_mes;
    float media_tempo_ano;
    
    estatisticas = fopen("historico.txt", "rb");
    
    if(estatisticas == NULL){
        puts("Erro ao tentar abrir o ficheiro!");
    }
    
     time_t rawtime;
     struct tm * ptm;
            
     time_t sec;
     sec = time (NULL);

     time ( &rawtime );

     ptm = gmtime ( &rawtime );
     
     //total de utilizadores
     
     while(fread(&parque, sizeof(PARQUEAMENTO), 1, estatisticas) == 1){
         if(parque.ativo == 0){
            //contar nº total de utilizadores
            contar_utilizadores++;
            
          if(parque.dia_entrada == (ptm->tm_mday) && parque.mes_entrada == (ptm->tm_mon)+1 && parque.ano_entrada == ((ptm->tm_year)-100)){
              contar_dia++;
              tempo_dia += parque.tempo;
          }
          if(parque.mes_entrada == (ptm->tm_mon)+1 && parque.ano_entrada == ((ptm->tm_year)-100)){
              contar_mes++;
              tempo_mes += parque.tempo;
          }
          if(parque.ano_entrada == ((ptm->tm_year)-100)){
              contar_ano++;
              tempo_dia += parque.tempo;
          }
         }
         
     }
     
     media_tempo_dia = tempo_dia / contar_dia;
     media_tempo_mes = tempo_mes / contar_mes;
     media_tempo_ano = tempo_ano / contar_ano;
     
     printf("Estatisticas\n");
     
     //total de utilizadores
     printf("Total de utilizadores: %d\n", contar_utilizadores);
     //utilizadores hoje
     printf("Utilizadores este hoje: %d\n", contar_dia);
     
     //utilizadores este mes
     printf("Utilizadores este mês: %d\n", contar_mes);
     
     //utilizadores este ano
     printf("Utilizadores este ano: %d\n", contar_ano);
     
     
     //media tempo utilizadores hoje
     
     printf("Tempo médio por utilizador hoje: %f\n", media_tempo_dia);
     
     //media tempo utilizadores mes
     printf("Tempo médio por utilizador este mês: %f\n", media_tempo_mes);
     
     //media tempo utilizadores ano
     printf("Tempo médio por utilizador este ano: %f\n", media_tempo_ano);
            
    
    fclose(estatisticas);
}