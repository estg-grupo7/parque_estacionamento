/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   gestao.h
 * Author: miguellima
 *
 * Created on 2 de Janeiro de 2018, 16:45
 */

#ifndef GESTAO_H
#define GESTAO_H

#ifdef __cplusplus
extern "C" {
#endif




#ifdef __cplusplus
}
#endif

#endif /* GESTAO_H */

void menu_gestao();
void entrada();
void historico();
void saida();