/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   parque.h
 * Author: miguellima
 *
 * Created on 1 de Janeiro de 2018, 16:21
 */

#ifndef PARQUE_H
#define PARQUE_H

#ifdef __cplusplus
extern "C" {
#endif




#ifdef __cplusplus
}
#endif

#endif /* PARQUE_H */

void flugares();
int ver_lugares();