/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   clientes.h
 * Author: miguellima
 *
 * Created on 1 de Janeiro de 2018, 16:16
 */

#ifndef CLIENTES_H
#define CLIENTES_H

#ifdef __cplusplus
extern "C" {
#endif




#ifdef __cplusplus
}
#endif

#endif /* CLIENTES_H */

void registar_cliente();
void listar_clientes();
int verificar_nif(char nif[]);
int verificar_matricula(char matricula[]);
void alterar_cliente();
int contar_clientes();
void remover_cliente();
int procurar(char stringA[], char tipo);
void procurar_id();