/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   estruturas.h
 * Author: miguellima
 *
 * Created on 1 de Janeiro de 2018, 16:01
 */


#define MATRICULA 6

#ifndef ESTRUTURAS_H
#define ESTRUTURAS_H

#ifdef __cplusplus
extern "C" {
#endif




#ifdef __cplusplus
}
#endif

#endif /* ESTRUTURAS_H */

typedef struct CLIENTES {
    int id;
    char nif[9 + 1];
    char nome[50];
    char tipo_veiculo;
    char matricula[MATRICULA];
    int lugar;
    char estado;
} CLIENTES;

typedef struct LUGARES {
    int numero;
    int id_cliente;
    int estado;
    int reservado;
    int ativo;
    char matricula[6 + 1];
} LUGARES;

typedef struct EMPRESA {
    char nome[50];
    char nif[9 + 1];
    int lugares;
    int tarifario;
} EMPRESA;

typedef struct PARQUEAMENTO {
    int hora_entrada;
    int minuto_entrada;
    int dia_entrada;
    int mes_entrada;
    int ano_entrada;

    int hora_saida;
    int minuto_saida;
    int dia_saida;
    int mes_saida;
    int ano_saida;

    int minutos_entrada;
    int minutos_saida;

    int tempo;

    char matricula[6 + 1];

    float preco;
    int ativo;
} PARQUEAMENTO;

typedef struct TARIFARIO {
    int id;
    float tempo_min;
    float tempo_max;
    int tempo_minutos;
    float mensalidade;
    float preco;
    int ativo;
} TARIFARIO;
