/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
//Inclui a biblioteca menu
#include "menu.h"
#include "estruturas.h"
#include "empresa.h"
#include "gestao.h"
#include "tarifarios.h"


#define UTC (0)
void entrada();
void historico();

void menu_gestao(){
    /**
     * Esta função é responsável por gerar o menu de gestao do parque de estacionamento,
     * 
     */
    
    int opcao;
    
    do{
        do{
            puts("1 - Dar Entrada Veiculo");
            puts("2 - Dar Saida Veiculo");
            puts("3 - Histórico");
            puts("0 - Voltar");
            printf("Escolha uma opção: ");
            scanf("%d", &opcao);
            system_clear();
        }while(opcao < 0 || opcao > 3);
        switch(opcao){
            case 1:
                system_clear();
                entrada();
                break;
            case 2:
                system_clear();
                saida();
                break;   
            case 3:
                system_clear();
                historico();
        }
    }while(opcao!=0);
}

void entrada(){
    
    /**
     * Esta função és responsável por dar entrada de um veiculo no parque de estacionamento
     */
    
    CLIENTES cliente;
    LUGARES lugar;
    PARQUEAMENTO parque;
    
    FILE *fp;
    FILE *gestao;
    FILE *registar;
    
    //variaveis de matricula
    int j, t, matricula_valida, matricula_existe = 0;
    char matricula[6];
    int numero_estacionamento = 0;
    int matricula_cliente;
    
    
    fp = fopen("lugares.txt", "rb");
    
    if(fp == NULL){
        printf("Erro ao tentar abrir o ficheiro!\n");
    }
    
    gestao = fopen("historico.txt", "ab");
    
    if(gestao == NULL){
        printf("Erro ao tentar abrir o ficheiro!\n");
    }
    
    registar = fopen("lugares.txt", "r+b");
    
    if(registar == NULL){
        printf("Erro ao tentar abrir o ficheiro!\n");
    }
    
     do{
            matricula_existe = 0;
            matricula_cliente = 0;
            
            time_t rawtime;
            struct tm * ptm;
            
            time_t sec;
            sec = time (NULL);

            time ( &rawtime );

            ptm = gmtime ( &rawtime );
            
            parque.hora_entrada = (ptm->tm_hour+UTC)%24;
            parque.minuto_entrada = (ptm->tm_min);
            
            parque.dia_entrada = (ptm->tm_mday);
            parque.mes_entrada = (ptm->tm_mon)+1;
            parque.ano_entrada = ((ptm->tm_year)-100);
            
            parque.minutos_entrada = sec/60;
            
            parque.hora_saida = 0;
            parque.minuto_saida = 0;
            
            parque.dia_saida = 0;
            parque.mes_saida = 0;
            parque.ano_saida = 0;
            
            parque.minutos_saida = 0;
            
            parque.preco = 0;
            parque.ativo = 1;
            parque.tempo = 0;
            
            fflush(stdin);
            printf("Matricula: ");
            scanf(" %[^\n]s", parque.matricula);
                        
            while(fread(&lugar, sizeof(LUGARES), 1, fp) == 1){
                if(strcmp(parque.matricula, lugar.matricula)==0){
                    if(lugar.estado != 0)
                        matricula_existe++;
                }
                if(strcmp(parque.matricula, lugar.matricula)==0){
                    if(lugar.ativo == 1)
                        matricula_cliente = 1;
                    else
                        matricula_cliente = 0;
                }
            }
            
            
            if(matricula_existe > 0)
                printf("O veiculo com esta matricula já se encontra no parque!");
            
            //transformar a matricula toda em lowercase
            for (j = 0; j < 6; j++){
                parque.matricula[j] = tolower(parque.matricula[j]);
            }

            for(t=0;t<6;t++)
                matricula[t] = (parque.matricula[t] - 48);

            if(matricula[0]+matricula[1]<19 && matricula[2]+matricula[3]<19 && matricula[4]+matricula[5]<19){
                matricula_valida  = 0;
            }else if(matricula[0]+matricula[1]>97 && matricula[2]+matricula[3]<19 && matricula[4]+matricula[5]<19){
                matricula_valida = 1;
            }else if(matricula[0]+matricula[1]<19 && matricula[2]+matricula[3]>97 && matricula[4]+matricula[5]<19){
                matricula_valida = 1;
            }else if(matricula[0]+matricula[1]<19 && matricula[2]+matricula[3]<19 && matricula[4]+matricula[5]>97){
                matricula_valida = 1;
            }else{
                matricula_valida  = 0;
            }
            
        }while(matricula_valida != 1 || matricula_existe != 0 || strlen(parque.matricula) > 6 ||strlen(parque.matricula) < 6 );
        
        if(matricula_cliente == 0){
            rewind(fp);

            while(fread(&lugar, sizeof(LUGARES), 1, fp) == 1){
                if(lugar.estado  == 0 && lugar.ativo ==0){
                    break;
                }
                numero_estacionamento++;
            }


            fseek(registar, (lugar.numero - 1)*sizeof(LUGARES), SEEK_SET);

            fread(&lugar, sizeof(LUGARES),1, registar);

            strlcpy(lugar.matricula, parque.matricula, 7);

            lugar.estado = 1;

            fseek(registar,-(long) sizeof(LUGARES), SEEK_CUR);

            fwrite(&lugar, sizeof(LUGARES), 1, registar);

        }else{
            rewind(fp);

            while(fread(&lugar, sizeof(LUGARES), 1, fp) == 1){
                if(strcmp(parque.matricula, lugar.matricula) == 0){
                    break;
                }
                numero_estacionamento++;
            }

            fseek(registar, (lugar.numero - 1)*sizeof(LUGARES), SEEK_SET);

            fread(&lugar, sizeof(LUGARES),1, registar);

            strlcpy(lugar.matricula, parque.matricula, 7);

            lugar.estado = 1;

            fseek(registar,-(long) sizeof(LUGARES), SEEK_CUR);

            fwrite(&lugar, sizeof(LUGARES), 1, registar);
        }
        
 
        fwrite(&parque, sizeof(PARQUEAMENTO), 1, gestao);
        fclose(registar);
        fclose(gestao);
        fclose(fp);
}

void saida(){
    
    /**
     * Esta função és responsável por dar saida de um veiculo no parque de estacionamento
     */
    
    
    int cliente_saida = 0;
    
    PARQUEAMENTO parque;
    PARQUEAMENTO parqueV;
    LUGARES lugar;
    EMPRESA empresa;
    TARIFARIO tarifa;
    
    char matricula[6+1];
    char verMatricula[6+1];
    
    int matricula_existe, matricula_cliente, matricula_valida, j, t;
    
    int contar_historico = 0;
    
    int contar_lugares = 0;
    
    float dinheiro_recebido, troco;
    
    FILE *verHistorico;
    
    verHistorico = fopen("historico.txt", "rb");
    
    if(verHistorico == NULL){
        printf("Erro ao tentar abrir o ficheiro!\n");
    }
    
    FILE *alterarParque;
    
    alterarParque = fopen("lugares.txt", "r+b");
    
    if(alterarParque == NULL){
        printf("Erro ao tentar abrir o ficheiro!\n");
    }
    
    FILE *alterarHistorico;
    
    alterarHistorico = fopen("historico.txt", "r+b");
    
    if(alterarHistorico == NULL){
        printf("Erro ao tentar abrir o ficheiro!\n");
    }
    
    FILE *alterarLugares;
    
    alterarLugares = fopen("lugares.txt", "r+b");
    
    if(alterarLugares == NULL){
        printf("Erro ao tentar abrir o ficheiro!\n");
    }
    
    FILE *verEmpresa;
    
    verEmpresa = fopen("empresa.txt", "rb");
    
    if(verEmpresa == NULL){
        printf("Erro ao tentar abrir o ficheiro!\n");
    }
    
    FILE *verTarifario;
    
    FILE *verSeCliente;
    
    verSeCliente = fopen("lugares.txt", "rb");
    
    if(verSeCliente == NULL){
        printf("Erro ao tentar abrir o ficheiro!\n");
    }
    
    fread(&empresa, sizeof(EMPRESA),1,verEmpresa);
    
    if(empresa.tarifario == 1){
        //tarifario por intervalos
        verTarifario = fopen("tarifario.txt", "rb");
    }else if(empresa.tarifario == 2){
        //tarifario por minutos
        verTarifario = fopen("mtarifario.txt", "rb");
    }
    
    if(verTarifario == NULL){
        printf("Erro ao tentar abrir o ficheiro!\n");
    }
    
     do{    
            contar_lugares = 0;
            contar_historico = 0;
            matricula_existe = 0;
            matricula_cliente = 0;

            
            parque.ativo = 0;
            
            fflush(stdin);
            printf("Matricula: ");
            scanf(" %[^\n]s", parque.matricula);
                
            time_t rawtime;
            struct tm * ptm;
            
            time_t sec;
            sec = time (NULL);

            time ( &rawtime );

            ptm = gmtime ( &rawtime );
            
              while(fread(&parqueV, sizeof(PARQUEAMENTO),1, alterarHistorico) == 1){
                    contar_historico++;
                    if(strcmp(parque.matricula, parqueV.matricula) == 0){
                        if(parqueV.ativo == 1){
                            break;
                        }
                    }
              }
                
            while(fread(&lugar, sizeof(LUGARES),1, verSeCliente) == 1){
                    if(strcmp(parque.matricula, lugar.matricula) == 0){
                        if(lugar.ativo == 1){
                            cliente_saida = 1;
                        }else{
                            cliente_saida = 0;
                        }
                    }
              }
                fseek(alterarHistorico, (contar_historico - 1) * sizeof(PARQUEAMENTO), SEEK_SET);
                
                fread(&parque, sizeof(PARQUEAMENTO),1, alterarHistorico);
                
                parque.hora_saida = (ptm->tm_hour+UTC)%24;
                parque.minuto_saida = (ptm->tm_min);
            
                parque.dia_saida = (ptm->tm_mday);
                parque.mes_saida = (ptm->tm_mon)+1;
                parque.ano_saida = ((ptm->tm_year)-100);
            
                parque.minutos_saida = sec/60;

                parque.ativo = 0;
                
                parque.tempo =  parque.minutos_saida -  parque.minutos_entrada;
                
                if(empresa.tarifario == 1){
                   //tarifario por intervalos
                   while(fread(&tarifa, sizeof(TARIFARIO),1, verTarifario) == 1){
                       if(parque.tempo >= tarifa.tempo_min && parque.tempo <= tarifa.tempo_max)
                           break;
                  }
                   
                   parque.preco = tarifa.preco;
                   
                   
               }else if(empresa.tarifario == 2){
                   //tarifario por minutos
                   fread(&tarifa, sizeof(TARIFARIO),1, verTarifario);
                   
                   parque.preco = parque.tempo * tarifa.preco;
                   
               }
                
                if(cliente_saida == 1)
                    parque.preco = 0;
                
                
                
                fseek(alterarHistorico, -(long) sizeof(PARQUEAMENTO), SEEK_CUR);
                
                fwrite(&parque, sizeof(PARQUEAMENTO),1,alterarHistorico);
                
              
              while(fread(&lugar, sizeof(LUGARES),1, alterarParque) == 1){
                    contar_lugares++;
                    if(strcmp(parque.matricula, lugar.matricula) == 0)
                        break;
              }
                
             
                
             fseek(alterarParque, (contar_lugares-1) * sizeof(LUGARES), SEEK_SET);
             fread(&lugar, sizeof(LUGARES),1, alterarParque);
             
             if(lugar.ativo == 1){
                   lugar.estado = 0;
                          
             }else{
              lugar.estado = 0;
             
              strlcpy(lugar.matricula, "aaaaaa", 7);
             
             }
             
             fseek(alterarParque, -(long) sizeof(LUGARES), SEEK_CUR);
             
             fwrite(&lugar, sizeof(LUGARES),1, alterarParque);

             
                
            

            //transformar a matricula toda em lowercase
            for (j = 0; j < 6; j++){
                parque.matricula[j] = tolower(parque.matricula[j]);
            }

            for(t=0;t<6;t++)
                matricula[t] = (parque.matricula[t] - 48);

            if(matricula[0]+matricula[1]<19 && matricula[2]+matricula[3]<19 && matricula[4]+matricula[5]<19){
                matricula_valida  = 0;
            }else if(matricula[0]+matricula[1]>97 && matricula[2]+matricula[3]<19 && matricula[4]+matricula[5]<19){
                matricula_valida = 1;
            }else if(matricula[0]+matricula[1]<19 && matricula[2]+matricula[3]>97 && matricula[4]+matricula[5]<19){
                matricula_valida = 1;
            }else if(matricula[0]+matricula[1]<19 && matricula[2]+matricula[3]<19 && matricula[4]+matricula[5]>97){
                matricula_valida = 1;
            }else{
                matricula_valida  = 0;
            }
            
        }while(matricula_valida != 1 || strlen(parque.matricula) > 6 ||strlen(parque.matricula) < 6 );
        
        if(cliente_saida == 1){
        
        }else if(cliente_saida == 0){
            printf("Total a pagar: %f", parque.preco);
            printf("Dinheiro Recebido : ");
            scanf("%f", &dinheiro_recebido);
            
            troco = dinheiro_recebido - parque.preco;
            
            printf("Troco: %4f", troco);
        }
    
                
        fclose(verSeCliente);
        fclose(verTarifario);
        fclose(verEmpresa);
        fclose(alterarLugares);
        fclose(alterarHistorico);
        fclose(alterarParque);
        fclose(verHistorico);
   
}

void historico(){
    
    /**
     * Esta função és responsável por guardar todos os registos de entrada, saida do parque de estacionamento
     */
    PARQUEAMENTO parque;
    
    FILE *fp;
    
    fp = fopen("historico.txt", "rb");
    
    if(fp == NULL){
        printf("Erro ao tentar abrir o ficheiro!\n");
    }
    /*
        int hora_entrada;
    int minuto_entrada;
    
    int hora_saida;
    int minuto_saida;
    
    int minutos_entrada;
    int minutos_saida;
    
    char matricula[MATRICULA];
    
    float preco;  
*/
    while(fread(&parque,sizeof(PARQUEAMENTO),1,fp) == 1){
        printf("Hora Entrada: %d\n", parque.hora_entrada);
        printf("Minuto Entrada: %d\n", parque.minuto_entrada);
        printf("Hora Saida: %d\n", parque.hora_saida);
        printf("Minuto Saida: %d\n", parque.minuto_saida);
        printf("Minutos Entrada: %d\n", parque.minutos_entrada);
        printf("Minutos Saida: %d\n", parque.minutos_saida);
        printf("Dia Entrada: %d\n", parque.dia_entrada);
        printf("Mês Entrada: %d\n", parque.mes_entrada);
        printf("Ano Entrada: %d\n", parque.ano_entrada);
        
        printf("Dia Saida: %d\n", parque.dia_saida);
        printf("Mês Saida: %d\n", parque.mes_saida);
        printf("Ano Saida: %d\n", parque.ano_saida);

        printf("Matricula: %s\n", parque.matricula);
        printf("Preço: %f\n", parque.preco);
        printf("Ativo: %d\n", parque.ativo);
        printf("Tempo no parque %d minutos\n",parque.tempo );
        printf("---------------------\n");
    }
    
    fclose(fp);
}
