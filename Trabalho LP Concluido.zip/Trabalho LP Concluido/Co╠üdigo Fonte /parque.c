/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
//Inclui a biblioteca menu
#include "menu.h"
#include "estruturas.h"
#include "empresa.h"
#include "parque.h"
#include "gestao.h"
#include "tarifarios.h"


void flugares(int lugares){
    
    /**
     * Esta função és responsável por criar o parque de utilizadores
     * @param lugares recebe o numero de lugares que a empresa deseja ter
     */
    
    /*
     * 1-ver quantos lugares existem 
     * 2-ver os lugares introduzidos pelo utilizador
     * 3-
     */
    
    LUGARES lugar;
    
    int i;
    
    int contar_lugares = 0;
    
    int n_lugares, l, lugares_adicionar;
    
    char matricula[7] = "aaaaaa";
    
    /*
     * Esta variavel serve para contar o numero de utilizadores 
     * com nº de lugar reservado maior que o nº de novos lugares
     */
    int lugar_ativo = 0, lugar_atual = 0;
        
    FILE *fp;
    FILE *fr;
    FILE *fp1;
    
    fp = fopen("lugares.txt", "ab");
    fr = fopen("lugares.txt", "rb");
    fp1 = fopen("lugares1.txt", "ab");
    
    if(fp == NULL){
        printf("Erro ao tentar abrir o ficheir!\n");
        fp = fopen("lugares.txt", "ab");
    }
    
    n_lugares = ver_lugares();

    if(lugares == n_lugares){
        printf("O valor de lugares introduzido é inválido devido: \n");
        printf("->Ser o número atual de lugares!\n");
    }else if( lugares > n_lugares){
        
        lugares_adicionar = lugares - n_lugares;
        
        for(l=1;l<=lugares_adicionar;l++){
            lugar.numero = n_lugares + l;
            lugar.id_cliente = 0;
            strlcpy(lugar.matricula, matricula, 7);
            lugar.estado = 0;
            lugar.reservado = 0;
            lugar.ativo = 0;
            fwrite(&lugar, sizeof(LUGARES), 1, fp);       
        }
    }else if(lugares < n_lugares){
        fseek(fr, (lugares-1)*sizeof(LUGARES), SEEK_SET);
        while(fread(&lugar, sizeof(LUGARES), 1, fr) == 1){
            if(lugar.ativo == 1)
                lugar_ativo++;
        }
        
        if(lugar_ativo > 0){
            printf("Atualize Primeiro os lugares reservados!");
            
        }else{
            rewind(fr);
            while(lugar_atual != lugares){
                fread(&lugar, sizeof(LUGARES), 1, fr);
                fwrite(&lugar, sizeof(LUGARES), 1, fp1);
                lugar_atual++;
            }
            
            remove("lugares.txt");
            rename("lugares1.txt", "lugares.txt");
        }
    }
        
    fclose(fp1);
    fclose(fr);
    fclose(fp);
}

int ver_lugares(){
    
    /**
     * Esta função é responsável por exibir os lugares do parque de estacionamento
     * @return o número total de lugares
     */
    
    LUGARES lugar;
    int contar = 0;
    FILE *th;
    
    th = fopen("lugares.txt", "rb");
    
    if(th==NULL){
        printf("Erro ao abrir o ficheiro!\n");
    }

    printf("\n========================\n");

    while(fread(&lugar, sizeof(LUGARES),1,th) == 1){
            //printf("%d %s %d %d %d %d\n", lugar.numero, lugar.matricula,lugar.estado, lugar.reservado, lugar.ativo, lugar.id_cliente);
            contar++;
            if(lugar.ativo == 1 && lugar.estado == 1)
                printf("RO");
            else if(lugar.ativo == 1)
                printf("RR");
            else if(lugar.estado == 1)
                printf("OO");
            else
                printf("%d", lugar.numero);
                
            

            
            if(contar <10)
                printf("  | ");
            else
                printf(" | ");
            
            if(contar % 5 == 0)
                printf("\n========================\n");
            

    }
    
    fclose(th);
    
    return contar;
}