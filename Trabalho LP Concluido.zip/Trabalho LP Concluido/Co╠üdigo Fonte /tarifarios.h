/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   tarifarios.h
 * Author: miguellima
 *
 * Created on 3 de Janeiro de 2018, 17:19
 */

#ifndef TARIFARIOS_H
#define TARIFARIOS_H

#ifdef __cplusplus
extern "C" {
#endif




#ifdef __cplusplus
}
#endif

#endif /* TARIFARIOS_H */

void tarifarios();
void adicionar_tarifa_intervalos();
void listar_tarifarios();
int verificar_limites_tempo(float a, float b);
int contar_tarifas();
void alterar_tarifario(int id_tarifario);
void definir_tarifa_minutos();
void remover_tarifario(int id_tarifario);