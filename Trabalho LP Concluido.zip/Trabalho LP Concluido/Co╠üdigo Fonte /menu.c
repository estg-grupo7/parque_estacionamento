/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**************************************************************************
 **************************************************************************
 ******                                                              ******
 ******  Este é o ficheiro responsável por gerar o menu do programa  ******
 ******                                                              ******
 **************************************************************************
 **************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
//Inclui a biblioteca menu
#include "menu.h"
#include "estruturas.h"
#include "clientes.h"
#include "empresa.h"
#include "parque.h"
#include "gestao.h"
#include "tarifarios.h"


//Esta constante define o número minimo de opções do menu
#define MENU_MIN 0
//Esta constante define o número de itens do menu
#define MENU_MAX 5


//Para determinar qual o sistema operativo que estamos a usar
#ifdef __unix__
#include <unistd.h>
#include <stdlib.h>

#elif defined(_WIN32) || defined(WIN32)

#define OS_Windows

#include <windows.h>

#endif


//Função Responsável por limpar o buffer do teclado

void clear(void) {
    /**
     * Esta função limpa o buffer do teclado
     */
    while (getchar() != '\n');
}

void asterisco(int numero, int linhas) {
    /**
     * Esta função escreve um determinado numero de * num determinado numero de linhas
     * @param numero recebe o numero de * a representar
     * @param linhas recebe o número de linhas a representar com asteriscos
     */
    int i, j;

    for (j = 0; j < linhas; j++) {
        for (i = 0; i < numero; i++)
            printf("*");
        printf("\n");
    }
}

void system_clear();

//Esta função apresenta todas as opções do que o utilizador
//pode utilizar quando utiliza a opção "Clientes"

void menu_clientes() {
    /**
     * Esta função é responsável por gerar o menu da opção clientes do menu principal
     */

    int opcao;
    int count = 0;
    CLIENTES cliente;
    system_clear();
    do {
        do {
            printf("\n");
            asterisco(30, 1);

            puts("***        Clientes        ***");

            asterisco(30, 1);

            puts("1 - Registar Cliente");
            puts("2 - Ver Cliente");
            puts("3 - Alterar CLiente");
            puts("4 - Remover Cliente");
            puts("5 - Procurar Cliente");
            puts("0 - Voltar");

            asterisco(30, 1);

            printf("Selecione uma opção do menu: ");
            scanf("%d", &opcao);
            system_clear();
        } while (opcao < 0 || opcao > 5);

        switch (opcao) {
            case 1:
                system_clear();
                registar_cliente();
                break;
            case 2:
                system_clear();
                listar_clientes();
                break;
            case 3:
                system_clear();
                listar_clientes();
                printf("\n\n");
                alterar_cliente(&cliente);
                break;
            case 4:
                system_clear();
                listar_clientes();
                printf("\n\n");
                remover_cliente();
                break;
            case 5:
                system_clear();
                procurar_cliente();
                break;
        }
    } while (opcao != 0);

}

void menu() {

    /**
     * Esta função é responsável por gerar o menu principal no nosso programa de gestão de um parque de estacionamento
     */

    //Esta variável vai receber a escolha do utilizador
    int opcao;
    do {

        do {
            printf("\n");
            asterisco(30, 1);

            puts("***          Menu          ***");

            asterisco(30, 1);

            puts("1 - Clientes");
            puts("2 - Parque");
            puts("3 - Estatísticas");
            puts("4 - Definições");
            puts("5 - Entradas e Saídas");
            puts("0 - Sair");

            asterisco(30, 1);

            printf("Selecione uma opção do menu: ");
            scanf("%d", &opcao);
            system_clear();
            asterisco(30, 1);

        } while (opcao < MENU_MIN || opcao > MENU_MAX);
        switch (opcao) {
            case 1:
                system_clear();
                menu_clientes();
                break;
            case 2:
                system_clear();
                ver_lugares();
                break;
            case 3:
                system_clear();
                estatisticas();
                break;
            case 4:
                system_clear();
                empresa();
                break;
            case 5:
                system_clear();
                menu_gestao();
                break;
            default:
                printf("Programa Encerrado!");
        }

    } while (opcao != 0);
}

void system_clear() {
    /**
     * Esta função serve para determinar qual o sistema operativo
     * para mais tarde limpar a tela
     */
#ifdef OS_Windows
    system("cls");
#else
    system("clear");
#endif
}

void dar_espacos(int c, int t) {
    /**
     * Esta função é responsável por dar espaços para exibição de resultados
     * @param c recebe o numero de caracteres da estrutura
     * @param t recebe o dobro de caracteres da estrutura
     */
    int i = 0;
    c = t - c;
    while (i < c) {
        printf(" ");
        i++;
    }
}

void dar_espacos_nome(int c, char nome[]) {
    /**
     * Esta função é responsável por dar espaços para exibição de resultados em função do tamanho da string nome[]
     * @param c tamanho maximo de nome
     * @param nome recebemos a string nome para obter o tamanho
     */
    int i = 0;
    int t;

    t = strlen(nome);

    c = c - t;
    while (i < c) {
        printf(" ");
        i++;
    }
}
