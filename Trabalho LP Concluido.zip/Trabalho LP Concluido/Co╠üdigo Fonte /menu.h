/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   menu.h
 * Author: miguellima
 *
 * Created on 24 de Dezembro de 2017, 11:04
 */

#ifndef MENU_H
#define MENU_H

#ifdef __cplusplus
extern "C" {
#endif




#ifdef __cplusplus
}
#endif

#endif /* MENU_H */

void menu();
void menu_clientes();
void system_clear();
void dar_espacos(int c, int t);
void dar_espacos_nome(int c, char nome[]);