var searchData=
[
  ['estado',['estado',['../struct_c_l_i_e_n_t_e_s.html#a7e1095f39132fe483fb94096dbf32195',1,'CLIENTES::estado()'],['../struct_l_u_g_a_r_e_s.html#a876d08c1d21086e4fd228744da10d028',1,'LUGARES::estado()']]]
];
