var searchData=
[
  ['ver_5flugares',['ver_lugares',['../parque_8c.html#a7412ee6965e0d1099f17d6f2697bc4b0',1,'ver_lugares():&#160;parque.c'],['../parque_8h.html#a7412ee6965e0d1099f17d6f2697bc4b0',1,'ver_lugares():&#160;parque.c']]],
  ['verificar_5flimites_5ftempo',['verificar_limites_tempo',['../tarifarios_8c.html#a3c77b7e585f3c4a1ed540b5250c99cf2',1,'verificar_limites_tempo(float a, float b):&#160;tarifarios.c'],['../tarifarios_8h.html#a3c77b7e585f3c4a1ed540b5250c99cf2',1,'verificar_limites_tempo(float a, float b):&#160;tarifarios.c']]],
  ['verificar_5fmatricula',['verificar_matricula',['../clientes_8c.html#a7dbcba3aff68b511bb25b43c64ee4f1e',1,'verificar_matricula(char matricula[]):&#160;clientes.c'],['../clientes_8h.html#a7dbcba3aff68b511bb25b43c64ee4f1e',1,'verificar_matricula(char matricula[]):&#160;clientes.c']]],
  ['verificar_5fnif',['verificar_nif',['../clientes_8c.html#a239aed672557439cb1cb3f4a01240733',1,'verificar_nif(char nif[]):&#160;clientes.c'],['../clientes_8h.html#a239aed672557439cb1cb3f4a01240733',1,'verificar_nif(char nif[]):&#160;clientes.c']]]
];
