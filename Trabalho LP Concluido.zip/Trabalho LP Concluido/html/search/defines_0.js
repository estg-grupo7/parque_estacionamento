var searchData=
[
  ['matricula',['MATRICULA',['../estruturas_8h.html#a3f5febb6495b245e3312ba11fe3ca7cd',1,'estruturas.h']]],
  ['menu_5fmax',['MENU_MAX',['../menu_8c.html#a69cc3a876e4218ba04991a00d9bec1ab',1,'menu.c']]],
  ['menu_5fmin',['MENU_MIN',['../menu_8c.html#ad49de3513ab2064d5e5a31740dd43ccf',1,'menu.c']]]
];
