var searchData=
[
  ['listar_5fclientes',['listar_clientes',['../clientes_8c.html#a9b198cd9ff8c5508e18eae72b8fb5190',1,'listar_clientes():&#160;clientes.c'],['../clientes_8h.html#a9b198cd9ff8c5508e18eae72b8fb5190',1,'listar_clientes():&#160;clientes.c']]],
  ['listar_5ftarifarios',['listar_tarifarios',['../tarifarios_8c.html#ab953d72e130058c7368d47c790f67144',1,'listar_tarifarios():&#160;tarifarios.c'],['../tarifarios_8h.html#ab953d72e130058c7368d47c790f67144',1,'listar_tarifarios():&#160;tarifarios.c']]],
  ['lugar',['lugar',['../struct_c_l_i_e_n_t_e_s.html#afff4b974945baf64dd5f929c0c53e4c8',1,'CLIENTES']]],
  ['lugares',['LUGARES',['../struct_l_u_g_a_r_e_s.html',1,'LUGARES'],['../struct_e_m_p_r_e_s_a.html#a1e3c1fe1d9e63e0c447b657dbe9531b9',1,'EMPRESA::lugares()'],['../estruturas_8h.html#a1ef4b136e735fc4758af4ace5ec13f7d',1,'LUGARES():&#160;estruturas.h']]]
];
