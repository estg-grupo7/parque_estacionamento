var searchData=
[
  ['utc',['UTC',['../gestao_8c.html#aeaa43124ae269273caa02c0117e3092d',1,'gestao.c']]]
];
