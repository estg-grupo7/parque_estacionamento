var searchData=
[
  ['lugares',['LUGARES',['../struct_l_u_g_a_r_e_s.html',1,'']]]
];
