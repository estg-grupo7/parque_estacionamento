var searchData=
[
  ['tarifarios_2ec',['tarifarios.c',['../tarifarios_8c.html',1,'']]],
  ['tarifarios_2eh',['tarifarios.h',['../tarifarios_8h.html',1,'']]]
];
