var searchData=
[
  ['saida',['saida',['../gestao_8c.html#a46851a69b6140500d8f59ad9b1683b01',1,'saida():&#160;gestao.c'],['../gestao_8h.html#a46851a69b6140500d8f59ad9b1683b01',1,'saida():&#160;gestao.c']]],
  ['system_5fclear',['system_clear',['../menu_8c.html#ae74b1376b6ef33cec102fc602b8eb63d',1,'system_clear():&#160;menu.c'],['../menu_8h.html#ae74b1376b6ef33cec102fc602b8eb63d',1,'system_clear():&#160;menu.c']]]
];
