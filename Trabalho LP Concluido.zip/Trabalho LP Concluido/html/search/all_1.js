var searchData=
[
  ['clear',['clear',['../menu_8c.html#ae683fe63c33c388e9ba1c6392dd477eb',1,'menu.c']]],
  ['clientes',['CLIENTES',['../struct_c_l_i_e_n_t_e_s.html',1,'CLIENTES'],['../estruturas_8h.html#a285053ef16d1c16638dd9e5a98206642',1,'CLIENTES():&#160;estruturas.h']]],
  ['clientes_2ec',['clientes.c',['../clientes_8c.html',1,'']]],
  ['clientes_2eh',['clientes.h',['../clientes_8h.html',1,'']]],
  ['contar_5fclientes',['contar_clientes',['../clientes_8c.html#a5da4f5205991d5e6aa4820133c3d70b0',1,'contar_clientes():&#160;clientes.c'],['../clientes_8h.html#a5da4f5205991d5e6aa4820133c3d70b0',1,'contar_clientes():&#160;clientes.c']]],
  ['contar_5ftarifas',['contar_tarifas',['../tarifarios_8c.html#a0d89b503aad9f139d39d9c974b41fdb3',1,'contar_tarifas():&#160;tarifarios.c'],['../tarifarios_8h.html#a0d89b503aad9f139d39d9c974b41fdb3',1,'contar_tarifas():&#160;tarifarios.c']]]
];
