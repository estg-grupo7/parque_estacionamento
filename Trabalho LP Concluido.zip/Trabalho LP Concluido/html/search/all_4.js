var searchData=
[
  ['flugares',['flugares',['../parque_8c.html#af74a9b3b400930f2400d0920757376fa',1,'flugares(int lugares):&#160;parque.c'],['../parque_8h.html#af0b414d32bed309f356e673bb9f887e0',1,'flugares():&#160;parque.h']]]
];
