var searchData=
[
  ['nif',['nif',['../struct_c_l_i_e_n_t_e_s.html#acbbfa6da2df30a39f2d75bcb801384cc',1,'CLIENTES::nif()'],['../struct_e_m_p_r_e_s_a.html#acbbfa6da2df30a39f2d75bcb801384cc',1,'EMPRESA::nif()']]],
  ['nome',['nome',['../struct_c_l_i_e_n_t_e_s.html#ad9b32a94f9054fd81f59b1118b8d53d2',1,'CLIENTES::nome()'],['../struct_e_m_p_r_e_s_a.html#ad9b32a94f9054fd81f59b1118b8d53d2',1,'EMPRESA::nome()']]],
  ['numero',['numero',['../struct_l_u_g_a_r_e_s.html#a2c30f43104974e72e2809fb4569804b0',1,'LUGARES']]]
];
