var searchData=
[
  ['main',['main',['../main_8c.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'main.c']]],
  ['menu',['menu',['../menu_8c.html#a2a0e843767aeea4f433a28b9c54f573a',1,'menu():&#160;menu.c'],['../menu_8h.html#a2a0e843767aeea4f433a28b9c54f573a',1,'menu():&#160;menu.c']]],
  ['menu_5fclientes',['menu_clientes',['../menu_8c.html#a3de170b769363d0687aac693d875f33a',1,'menu_clientes():&#160;menu.c'],['../menu_8h.html#a3de170b769363d0687aac693d875f33a',1,'menu_clientes():&#160;menu.c']]],
  ['menu_5fgestao',['menu_gestao',['../gestao_8c.html#a0b99fd4302728550581a0f1b5dd75200',1,'menu_gestao():&#160;gestao.c'],['../gestao_8h.html#a0b99fd4302728550581a0f1b5dd75200',1,'menu_gestao():&#160;gestao.c']]]
];
