var searchData=
[
  ['lugar',['lugar',['../struct_c_l_i_e_n_t_e_s.html#afff4b974945baf64dd5f929c0c53e4c8',1,'CLIENTES']]],
  ['lugares',['lugares',['../struct_e_m_p_r_e_s_a.html#a1e3c1fe1d9e63e0c447b657dbe9531b9',1,'EMPRESA']]]
];
