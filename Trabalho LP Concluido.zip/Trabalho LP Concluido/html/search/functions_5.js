var searchData=
[
  ['historico',['historico',['../gestao_8c.html#aa006ef7faf186a8dd519d281d2115c2e',1,'historico():&#160;gestao.c'],['../gestao_8h.html#aa006ef7faf186a8dd519d281d2115c2e',1,'historico():&#160;gestao.c']]]
];
