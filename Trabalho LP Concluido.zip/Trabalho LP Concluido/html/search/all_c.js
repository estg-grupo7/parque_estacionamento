var searchData=
[
  ['registar_5fcliente',['registar_cliente',['../clientes_8c.html#a3cbdb1934824923607158f74efc01822',1,'registar_cliente():&#160;clientes.c'],['../clientes_8h.html#a3cbdb1934824923607158f74efc01822',1,'registar_cliente():&#160;clientes.c']]],
  ['remover_5fcliente',['remover_cliente',['../clientes_8c.html#aaba535d7e4abe0df8cef2f09ac275d51',1,'remover_cliente():&#160;clientes.c'],['../clientes_8h.html#aaba535d7e4abe0df8cef2f09ac275d51',1,'remover_cliente():&#160;clientes.c']]],
  ['remover_5ftarifario',['remover_tarifario',['../tarifarios_8c.html#a87dbba51399b9956b1356fe9d9a75193',1,'remover_tarifario(int id_tarifario):&#160;tarifarios.c'],['../tarifarios_8h.html#a87dbba51399b9956b1356fe9d9a75193',1,'remover_tarifario(int id_tarifario):&#160;tarifarios.c']]],
  ['reservado',['reservado',['../struct_l_u_g_a_r_e_s.html#a47f21277f50c7c85b50d3d9c28a614eb',1,'LUGARES']]]
];
