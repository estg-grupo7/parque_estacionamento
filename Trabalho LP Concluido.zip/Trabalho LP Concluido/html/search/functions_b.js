var searchData=
[
  ['tarifarios',['tarifarios',['../tarifarios_8c.html#a8d48ffb55407f7f94f10f84d7605cf9e',1,'tarifarios():&#160;tarifarios.c'],['../tarifarios_8h.html#a8d48ffb55407f7f94f10f84d7605cf9e',1,'tarifarios():&#160;tarifarios.c']]]
];
