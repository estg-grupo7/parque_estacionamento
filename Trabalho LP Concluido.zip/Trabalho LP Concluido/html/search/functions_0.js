var searchData=
[
  ['adicionar_5ftarifa_5fintervalos',['adicionar_tarifa_intervalos',['../tarifarios_8c.html#a9bec7a8150343d5e0f59c19d5b719307',1,'adicionar_tarifa_intervalos():&#160;tarifarios.c'],['../tarifarios_8h.html#a9bec7a8150343d5e0f59c19d5b719307',1,'adicionar_tarifa_intervalos():&#160;tarifarios.c']]],
  ['alterar_5fcliente',['alterar_cliente',['../clientes_8c.html#aa19efc00be3af316c75b779a60f71181',1,'alterar_cliente():&#160;clientes.c'],['../clientes_8h.html#aa19efc00be3af316c75b779a60f71181',1,'alterar_cliente():&#160;clientes.c']]],
  ['alterar_5ftarifario',['alterar_tarifario',['../tarifarios_8c.html#a750d42f2e98cd042a2cb77da61bfd0b9',1,'alterar_tarifario(int id_tarifario):&#160;tarifarios.c'],['../tarifarios_8h.html#a750d42f2e98cd042a2cb77da61bfd0b9',1,'alterar_tarifario(int id_tarifario):&#160;tarifarios.c']]],
  ['asterisco',['asterisco',['../menu_8c.html#a8ec6b6f67490464c5b2ba16913c60e1e',1,'menu.c']]]
];
