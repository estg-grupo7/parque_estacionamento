var searchData=
[
  ['adicionar_5ftarifa_5fintervalos',['adicionar_tarifa_intervalos',['../tarifarios_8c.html#a9bec7a8150343d5e0f59c19d5b719307',1,'adicionar_tarifa_intervalos():&#160;tarifarios.c'],['../tarifarios_8h.html#a9bec7a8150343d5e0f59c19d5b719307',1,'adicionar_tarifa_intervalos():&#160;tarifarios.c']]],
  ['alterar_5fcliente',['alterar_cliente',['../clientes_8c.html#aa19efc00be3af316c75b779a60f71181',1,'alterar_cliente():&#160;clientes.c'],['../clientes_8h.html#aa19efc00be3af316c75b779a60f71181',1,'alterar_cliente():&#160;clientes.c']]],
  ['alterar_5ftarifario',['alterar_tarifario',['../tarifarios_8c.html#a750d42f2e98cd042a2cb77da61bfd0b9',1,'alterar_tarifario(int id_tarifario):&#160;tarifarios.c'],['../tarifarios_8h.html#a750d42f2e98cd042a2cb77da61bfd0b9',1,'alterar_tarifario(int id_tarifario):&#160;tarifarios.c']]],
  ['ano_5fentrada',['ano_entrada',['../struct_p_a_r_q_u_e_a_m_e_n_t_o.html#a2e49c9f291640b9a3c7cbb2a6b991a00',1,'PARQUEAMENTO']]],
  ['ano_5fsaida',['ano_saida',['../struct_p_a_r_q_u_e_a_m_e_n_t_o.html#a13e31880f0879501f1a2e205c9f5ad0a',1,'PARQUEAMENTO']]],
  ['asterisco',['asterisco',['../menu_8c.html#a8ec6b6f67490464c5b2ba16913c60e1e',1,'menu.c']]],
  ['ativo',['ativo',['../struct_l_u_g_a_r_e_s.html#a5bc3bc4334890083c1af35103dae7964',1,'LUGARES::ativo()'],['../struct_p_a_r_q_u_e_a_m_e_n_t_o.html#a5bc3bc4334890083c1af35103dae7964',1,'PARQUEAMENTO::ativo()'],['../struct_t_a_r_i_f_a_r_i_o.html#a5bc3bc4334890083c1af35103dae7964',1,'TARIFARIO::ativo()']]]
];
