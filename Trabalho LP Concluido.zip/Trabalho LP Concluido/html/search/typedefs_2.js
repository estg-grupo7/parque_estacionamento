var searchData=
[
  ['lugares',['LUGARES',['../estruturas_8h.html#a1ef4b136e735fc4758af4ace5ec13f7d',1,'estruturas.h']]]
];
