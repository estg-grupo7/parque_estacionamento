var indexSectionsWithContent =
{
  0: "acdefghilmnprstuv",
  1: "celpt",
  2: "cegmpt",
  3: "acdefhlmprstv",
  4: "adehilmnprt",
  5: "celpt",
  6: "mu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros"
};

