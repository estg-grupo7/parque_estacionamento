var searchData=
[
  ['reservado',['reservado',['../struct_l_u_g_a_r_e_s.html#a47f21277f50c7c85b50d3d9c28a614eb',1,'LUGARES']]]
];
